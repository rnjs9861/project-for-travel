import React from "react";

const useModal = () => {
  return <div>useModal</div>;
};

export default useModal;
