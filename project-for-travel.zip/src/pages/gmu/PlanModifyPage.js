import React from "react";
import PlanModify from "../../components/gmu/PlanModify";

const PlanModifyPage = () => {
  return <PlanModify></PlanModify>;
};

export default PlanModifyPage;
