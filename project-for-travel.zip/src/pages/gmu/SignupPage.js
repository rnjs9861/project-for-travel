import React from "react";
import Signup from "../../components/gmu/Signup";

const SignupPage = () => {
  return (
    <div>
      <Signup></Signup>
    </div>
  );
};

export default SignupPage;
