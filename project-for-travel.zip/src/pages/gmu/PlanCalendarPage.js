import React from "react";
import PlanCalendar from "../components/PlanCalendar";

const PlanCalendarPage = () => {
  return (
    <>
      <PlanCalendar></PlanCalendar>
    </>
  );
};

export default PlanCalendarPage;
