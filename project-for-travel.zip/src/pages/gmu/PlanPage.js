import React from "react";
import Plan from "../../components/gmu/Plan";

const PlanPage = () => {
  return (
    <>
      <Plan></Plan>
    </>
  );
};

export default PlanPage;
