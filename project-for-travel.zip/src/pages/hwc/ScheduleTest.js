import React from "react";
import Test from "../../components/hwc/Test";

const ScheduleTest = () => {
  return <Test></Test>;
};

export default ScheduleTest;
