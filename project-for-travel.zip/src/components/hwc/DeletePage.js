import React from "react";

const DeletePage = () => {
  return <div>DeletePage</div>;
};

export default DeletePage;
