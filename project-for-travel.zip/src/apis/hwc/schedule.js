import axios from "axios";

export const scheDule = data => {
  try {
    const response = axios.post();
  } catch (error) {}
};
